<?php


namespace App\Services\Menu;


use App\Repositories\Menu\MenuRepository;
use App\Repositories\MenuCategory\MenuCategoryRepository;
use Illuminate\Http\Request;

class MenuServiceImpl implements MenuService
{
    private $menuRepository;
    private $menuCategoryRepository;

    public function __construct(MenuRepository $menuRepository,
                                MenuCategoryRepository $menuCategoryRepository)
    {
        $this->menuRepository = $menuRepository;
        $this->menuCategoryRepository = $menuCategoryRepository;
    }

    public function showMenuList()
    {
        return $this->menuRepository->getAllMenuList();
    }

    public function showMenuDetail($menuId)
    {
        $result = array();
        $result['menuDetail'] = $this->menuRepository->getMenuById($menuId);
        $result['menuCategoryList'] = $this->menuCategoryRepository->getAllMenuCategoryList();
        return $result;
    }

    public function deleteMenu($menuId)
    {
        $this->menuRepository->deleteMenuById($menuId);
    }

    public function updateMenu(Request $request)
    {
        $menuData = array();
        $menuId = $request->post('menuId');
        $menuData['menuCategoryId'] = $request->post('menuCategoryId');
        $menuData['name'] = $request->post('name');
        $menuData['price'] = $request->post('price');
        // get image fileUpload
        if (isset($_POST['up']) && isset($_FILES['fileUpload'])) {
            if ($_FILES['fileUpload']['error'] > 0)
                echo "Upload error!";
            else {
                move_uploaded_file(
                    $_FILES['fileUpload']['tmp_name'],
                    'images/' . $_FILES['fileUpload']['name']
                );
                $path = $_FILES['fileUpload']['name'];
                $menuData["image"] = "images/" . $path;
            }
        }
        $this->menuRepository->updateMenu($menuId, $menuData);
    }
}