<?php


namespace App\Services\Menu;


use Illuminate\Http\Request;

interface MenuService
{
    public function showMenuList();
    public function showMenuDetail($menuId);
    public function deleteMenu($menuId);
    public function updateMenu(Request $request);
}