<?php

namespace App\Services\Order;


use Illuminate\Http\Request;

interface OrderService
{
    public function showOrderList();

    public function showOrderDetail($orderId);

    public function showOrderEditForm($orderId);

    public function showOrderCreateForm();

    public function deleteOrder($orderId);

    public function updateOrder(Request $request);

    public function createOrder(Request $request);

}