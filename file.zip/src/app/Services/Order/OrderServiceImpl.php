<?php

namespace App\Services\Order;

use App\Repositories\Menu\MenuRepository;
use App\Repositories\MenuCategory\MenuCategoryRepository;
use App\Repositories\Order\OrderRepository;
use App\Repositories\OrderDetail\OrderDetailRepository;
use DateTime;
use Illuminate\Http\Request;

class OrderServiceImpl implements OrderService
{
    private $orderRepository;
    private $orderDetailRepository;
    private $menuRepository;
    private $menuCategoryRepository;

    public function __construct(OrderRepository $orderRepository,
                                OrderDetailRepository $orderDetailRepository,
                                MenuRepository $menuRepository,
                                MenuCategoryRepository $menuCategoryRepository)
    {
        $this->orderRepository = $orderRepository;
        $this->orderDetailRepository = $orderDetailRepository;
        $this->menuRepository = $menuRepository;
        $this->menuCategoryRepository = $menuCategoryRepository;

    }


    public function showOrderList()
    {
        $orderList = $this->orderRepository->getAllOrder();
        return $orderList;
    }


    public function showOrderDetail($orderId)
    {

        $result = array();
        $result['orderData'] = $this->orderRepository->getOrderById($orderId);
        $arr = $this->orderDetailRepository->getOrderDetailListById($orderId);
        $orderDetailList = array();

        for ($i = 0; $i < sizeof($arr); $i++) {

            //get data from array
            $object = $arr[$i];
            $quantity = $object["quantity"];
            $price = $object["price"];
            $menuName = $object["menuName"];
            $menuCategoryName = $object["menuCategoryName"];

            //check data and create new of array
            if (!array_key_exists($menuCategoryName, $orderDetailList)) {
                //create new of orderDetailList array
                $orderDetailList[$menuCategoryName] = array();
            }

            //add data to array
            $temp = array();
            $temp["quantity"] = $quantity;
            $temp["price"] = $price;
            $temp["menuName"] = $menuName;
            $temp["menuCategoryName"] = $menuCategoryName;
            array_push($orderDetailList[$menuCategoryName], $temp);
        }
        $total = 0;
        foreach ($orderDetailList as $key => $value) {
            foreach ($value as $order)
                $total = $total + $order['price'] * $order['quantity'];
        }
        $result['orderDetailList'] = $orderDetailList;
        $result['totalPrice'] = $total;
        return $result;
    }

    public function showOrderEditForm($orderId)
    {
        $result = $this->showOrderDetail($orderId);

        $result['orderDetailData'] = $this->orderDetailRepository->getOrderDetailListById($orderId);

//        echo $result['orderDetailData'];

        // Get all Menu List
        $result['menuList'] = $this->menuRepository->getAllMenuList();
//        echo $result['menuList'];

        //Get all Menu Category List
        $result['menuCategoryList'] = $this->menuCategoryRepository->getAllMenuCategoryList();

        return $result;
    }

    public function showOrderCreateForm()
    {
        //Get all Menu List
        $result['menuList'] = $this->menuRepository->getAllMenuList();
//        echo $result['menuList'];

        //Get all Menu Category List
        $result['menuCategoryList'] = $this->menuCategoryRepository->getAllMenuCategoryList();
//        echo $result['menuCategoryList'];
        return $result;
    }

    public function deleteOrder($orderId)
    {
        $this->orderRepository->deleteOrderById($orderId);
        $this->orderDetailRepository->deleteOrderDetailById($orderId);

    }

    public function updateOrder(Request $request)
    {
        // get menuIdList, quantityList, orderId values from request
        $menuIdList = $request->post('menuId');
        $quantityList = $request->post('menuQuantity');
        $orderId = $request->post('orderId');
//      var_dump($menuIdList,$quantityList,$orderId);

        // delete order detail
        $this->orderDetailRepository->deleteOrderDetailById($orderId);

        // for loop array row and insert
        for ($i = 0; $i < sizeof($menuIdList); $i++) {
            $menuId = $menuIdList[$i];
            $quantity = $quantityList[$i];
            $this->orderDetailRepository->insertOrderDetail($orderId, $menuId, $quantity);
        }
    }
    public function insertOrder($userId, $datetime)
    {
        $id = $this->orderRepository->insertOrder($userId, $datetime);
        return $id;
    }
    public function createOrder(Request $request)
    {
        $userId = "1";
        $datetime = new DateTime();

        // insert order row and get last orderId
        $result = $this->orderRepository->insertOrder($userId, $datetime);

        // get menuIdList, quantityList, orderId values from request
        $menuIdList = $request->post('menuId');
        $quantityList = $request->post('quantity');
        $orderId = $result;

//         for loop array row and insert order detail
        for ($i = 0; $i < sizeof($menuIdList); $i++) {
            $menuId = $menuIdList[$i];
            $quantity = $quantityList[$i];
            $this->orderDetailRepository->insertOrderDetail($orderId, $menuId, $quantity);
        }
    }
}
