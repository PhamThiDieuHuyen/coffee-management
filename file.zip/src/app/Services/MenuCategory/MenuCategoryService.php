<?php


namespace App\Services\MenuCategory;


use Illuminate\Http\Request;

interface MenuCategoryService
{
    public function showMenuCategoryList();

    public function showMenuCategoryDetail($menuCategoryId);

    public function deleteMenuCategory($menuCategoryId);

    public function updateMenuCategory(Request $request);
}