<?php


namespace App\Services\MenuCategory;


use App\Repositories\MenuCategory\MenuCategoryRepository;
use Illuminate\Http\Request;


class MenuCategoryServiceImpl implements MenuCategoryService
{
    private $menuCategoryRepository;

    public function __construct(MenuCategoryRepository $menuCategoryRepository)
    {
        $this->menuCategoryRepository = $menuCategoryRepository;
    }
    public function showMenuCategoryList()
    {
        return $this->menuCategoryRepository->getAllMenuCategoryList();
    }

    public function showMenuCategoryDetail($menuCategoryId)
    {
        $result=array();
        $result['menuCategoryDetail'] = $this->menuCategoryRepository->getMenuCategoryById($menuCategoryId);
        $result['menuCategoryList'] = $this->menuCategoryRepository->getAllMenuCategoryList();
        return $result;

    }
    public function deleteMenuCategory($menuCategoryId)
    {
        $menuCategoryDetail = $this->menuCategoryRepository->deleteMenuCategory($menuCategoryId);
        return $menuCategoryDetail;

    }
    public function updateMenuCategory(Request $request)
    {
        $menuCategoryData = array();
        $menuCategoryId = $request->post('menuCategoryId');
        $menuCategoryData['name'] = $request->post('menuCategoryName');
        $menuCategoryData['describe'] = $request->post('menuCategoryDescribe');
        $this->menuCategoryRepository->updateMenuCategory($menuCategoryId,$menuCategoryData);
    }
}