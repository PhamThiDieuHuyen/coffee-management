<?php

namespace App\Repositories\OrderDetail;

use App\Models\OrderDetail;

class OrderDetailRepositoryImpl implements OrderDetailRepository
{

    public function getOrderDetailListById($orderId)
    {
        $result = OrderDetail::join('menu', 'menu.menuId', '=', 'order_detail.menuId')
            ->join('menu_category', 'menu_category.menuCategoryId', '=', 'menu.menuCategoryId')
            ->select('*', 'menu.name AS menuName', 'menu_category.NAME AS menuCategoryName')
            ->where('order_detail.orderId', $orderId)
            ->get();
        return $result;
    }

    public function deleteOrderDetailById($orderId)
    {
        OrderDetail::where('orderId', '=', $orderId)->delete();
    }

    public function insertOrderDetail($orderId, $menuId, $quantity)
    {
        OrderDetail::insert(
            [
                'orderId' => $orderId,
                'menuId' => $menuId,
                'quantity' => $quantity,
            ]
        );
    }
}