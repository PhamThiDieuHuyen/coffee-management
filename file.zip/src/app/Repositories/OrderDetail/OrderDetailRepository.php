<?php

namespace App\Repositories\OrderDetail;

interface OrderDetailRepository
{
    public function getOrderDetailListById($orderId);

    public function insertOrderDetail($orderId, $menuId, $quantity);

    public function deleteOrderDetailById($orderId);
}