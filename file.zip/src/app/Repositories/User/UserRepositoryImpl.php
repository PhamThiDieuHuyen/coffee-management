<?php


namespace App\Repositories\User;


use App\Models\User;

class UserRepositoryImpl implements UserRepository
{
    public function getAllUserList()
    {
        $result = User::all();
        return $result;
    }

    public function getUserById($userId)
    {
        $result = User::find($userId);
        return $result;
    }

    public function deleteUserById($userId)
    {
        User::where('userId', '=', $userId)->delete();
    }
    public function updateUserById($userId,$userData)
    {
        User::where('userId', '=', $userId)->update($userData);
    }
}
