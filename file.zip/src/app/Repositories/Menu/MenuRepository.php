<?php


namespace App\Repositories\Menu;


interface MenuRepository
{
    public function getAllMenuList();

    public function getMenuById($menuId);

    public function deleteMenuById($menuId);

    public function updateMenu($menuId, $menuData);
}