<?php


namespace App\Repositories\Menu;


use App\Models\Menu;

class MenuRepositoryImpl implements MenuRepository
{
    public function getAllMenuList()
    {
        $result= Menu::join('menu_category', 'menu.menuCategoryId', '=', 'menu_category.menuCategoryId')
            ->select('menu.*', 'menu_category.name as menuCategoryName')->get();
        return $result;
    }

    public function getMenuById($menuId)
    {
        $result = Menu::select('menu.*', 'menu_category.name as menuCategoryName')
            ->join('menu_category', 'menu.menuCategoryId', '=', 'menu_category.menuCategoryId')
            ->find($menuId);
        return $result;
    }

    public function deleteMenuById($menuId)
    {
        Menu::where('menuId', '=', $menuId)->delete();
    }
    public function updateMenu($menuId, $menuData)
    {
        Menu::where('menuId', '=', $menuId)->update($menuData);
    }
}