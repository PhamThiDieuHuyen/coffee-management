<?php

namespace App\Repositories\Order;

interface OrderRepository
{
    public function getAllOrder();

    public function getOrderById($orderId);

    public function deleteOrderById($orderId);

    public function insertOrder($userId, $datetime);

}