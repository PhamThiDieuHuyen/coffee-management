<?php

namespace App\Repositories\Order;

use App\Models\Order;

class OrderRepositoryImpl implements OrderRepository
{

    public function getAllOrder()
    {
        return Order::get();

    }

    public function getOrderById($orderId)
    {
        $response = Order::join('user', 'user.userId', '=', 'order_trs.userId')
            ->where('order_trs.orderId', $orderId)
            ->first();
        return $response;
    }

    public function deleteOrderById($orderId)
    {
        Order::where('orderId', '=', $orderId)->delete();
    }
    public function insertOrder($userId, $datetime)
    {
        $id = Order::insertGetId(
                [
                    'userId' => $userId,
                    'datetime'=> $datetime
                ]
            );
        return $id;
    }
}