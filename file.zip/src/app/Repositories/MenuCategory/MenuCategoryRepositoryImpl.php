<?php


namespace App\Repositories\MenuCategory;


use App\Models\MenuCategory;

class MenuCategoryRepositoryImpl implements MenuCategoryRepository
{
    public function getAllMenuCategoryList()
    {
        $result= MenuCategory::get();
        return $result;
    }

    public function getMenuCategoryById($menuCategoryId)
    {
        $result = MenuCategory::find($menuCategoryId);
        return $result;
    }
    public function deleteMenuCategory($menuCategoryId)
    {
        $result = MenuCategory::where('menuCategoryId', '=', $menuCategoryId)->delete();
        return $result;
    }
    public function updateMenuCategory($menuCategoryId,$menuCategoryData)
    {
        MenuCategory::where('menuCategoryId', '=', $menuCategoryId)->update($menuCategoryData);
    }
}