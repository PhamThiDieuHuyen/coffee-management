<?php


namespace App\Repositories\MenuCategory;


interface MenuCategoryRepository
{
    public function getAllMenuCategoryList();

    public function getMenuCategoryById($menuCategoryId);

    public function deleteMenuCategory($menuCategoryId);

    public function updateMenuCategory($menuCategoryId,$menuCategoryData);
}