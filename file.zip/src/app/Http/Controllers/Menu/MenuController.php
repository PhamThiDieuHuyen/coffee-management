<?php


namespace App\Http\Controllers\Menu;

use App\Services\Menu\MenuService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;


class MenuController extends BaseController
{

    private $menuService;

    public function __construct(MenuService $menuService)
    {
        $this->menuService = $menuService;
    }

    public function showMenuList()
    {
        $result = $this->menuService->showMenuList();
        return view('menu.menu_list')->with('result', $result);
    }

    public function showMenuDetail($menuId)
    {
        $result = $this->menuService->showMenuDetail($menuId);
        return view('menu.menu_detail')->with('result', $result);
    }

    public function deleteMenu($menuId)
    {
        $this->menuService->deleteMenu($menuId);
        return redirect()->route('menu.showMenuList');

    }

    public function updateMenu(Request $request)
    {
        $this->menuService->updateMenu($request);
        return redirect()->route('menu.showMenuDetail',["menuId" => $request->post("menuId")]);
    }

}