<?php


namespace App\Http\Controllers\Order;

use App\Services\Order\OrderService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;


class OrderController extends BaseController
{
    private $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->orderService = $orderService;
    }

    public function showOrderList()
    {
        $result = $this->orderService->showOrderList();
        return view('order.order_list')->with('result', $result);
    }

    public function showOrderDetail($orderId)
    {
        $result = $this->orderService->showOrderDetail($orderId);
        return view('order.order_detail')->with('result', $result);
    }

    public function showOrderEditForm($orderId)
    {
        $result = $this->orderService->showOrderEditForm($orderId);
        return view('order.order_edit')->with('result', $result);
    }

    public function showOrderCreateForm()
    {
        $result = $this->orderService->showOrderCreateForm();
        return view('order.order_create')->with('result', $result);
    }
    public function deleteOrder($orderId)
    {
        $this->orderService->deleteOrder($orderId);
        return redirect()->route('order.showOrderList');
    }

    public function updateOrder(Request $request)
    {
        $this->orderService->updateOrder($request);
        return redirect()->route('order.showOrderDetail', ['orderId' => $request->post('orderId')]);
    }
    public function createOrder(Request $request)
    {
        $this->orderService->createOrder($request);
        return redirect()->route('order.showOrderCreateForm');
    }


}