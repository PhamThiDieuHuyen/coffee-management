<?php

namespace App\Http\Controllers\MenuCategory;

use App\Services\MenuCategory\MenuCategoryService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;

class MenuCategoryController extends BaseController
{
    private $menuCategoryService;

    public function __construct(MenuCategoryService $menuCategoryService)
    {
        $this->menuCategoryService = $menuCategoryService;
    }

    public function showMenuCategoryList()
    {
        $result = $this->menuCategoryService->showMenuCategoryList();
        return view('menuCategory.menu_category_list')->with('result', $result);
    }
    public function showMenuCategoryDetail($menuCategoryId)
    {
        $result=$this->menuCategoryService->showMenuCategoryDetail($menuCategoryId);
        return view('menuCategory.menu_category_detail')->with('result', $result);
    }
    public function deleteMenuCategory($menuCategoryId)
    {
        $this->menuCategoryService->deleteMenuCategory($menuCategoryId);
        return redirect()->route('menuCategory.showMenuCategoryList');
    }
    public function updateMenuCategory(Request $request)
    {
        $this->menuCategoryService->updateMenuCategory($request);
        return redirect()->route('menuCategory.showMenuCategoryList');
    }

}
