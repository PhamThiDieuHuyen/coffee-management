<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            <li><a><i class="fa fa-users"></i> User</a></li>
            <li><a><i class="fa fa-chevron-circle-down"></i> Menu</a></li>
        </ul>
    </div>
</div>
<?php /* C:\xampp\htdocs\coffee-management\src\resources\views/layout/menu/sidebar.blade.php */ ?>