<div class="sidebar-footer hidden-small sidebar-footer-coffee">
    <a data-toggle="tooltip" data-placement="top" title="Settings">
        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
    </a>
    <a data-toggle="tooltip" data-placement="top" title="FullScreen">
        <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
    </a>
    <a data-toggle="tooltip" data-placement="top" title="Lock">
        <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
    </a>
    <a data-toggle="tooltip" data-placement="top" title="Logout"
       href="http://127.0.0.1:8000/logout" onclick="event.preventDefault();
       document.getElementById('logout-form').submit();">
        <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
    </a>
</div><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/layout/menu/menu_footer.blade.php ENDPATH**/ ?>