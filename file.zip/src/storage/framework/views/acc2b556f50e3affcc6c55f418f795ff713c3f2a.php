<?php $__env->startSection('title'); ?>
    <div class="col-md-10 col-sm-12" style="padding: 0;">
        <h2>Menu Category list</h2>
    </div>
    <div class="col-md-2 col-sm-12" style="padding: 4px 0 0 43px;">
        <a href="#">
            <button type="button" class="create-menu-category btn cursor-pointer">
                <i class="fa fa-plus-square"></i> Create New
            </button>
        </a>
    </div>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table id="menu-category-table" class="table table-striped">
        <thead>
        <tr>
            <th class="col-md-2">Menu Category Id</th>
            <th class="col-md-2">Name</th>
            <th class="col-md-7">Describe</th>
            <th class="col-md-1">Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="menu-category-row cursor-pointer" data-menu-category-id="<?php echo e($menuCategory['menuCategoryId']); ?>">
                <td><?php echo e($menuCategory['menuCategoryId']); ?></td>
                <td><?php echo e($menuCategory['name']); ?></td>
                <td><?php echo e($menuCategory['describe']); ?></td>
                <td>
                    <button type="button" class="delete-menu-category btn cursor-pointer"
                            data-toggle="modal"
                            data-menu-category-id="<?php echo e($menuCategory['menuCategoryId']); ?>">
                        <i class="fa fa-trash"></i></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!-- Large modal -->
    <div class="modal fade confirm-delete-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">CONFIRM DELETE</h4>
                </div>
                <div class="modal-body">
                    <h4>WARNING!</h4>
                    <p>Are you sure you want to delete this menu category?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn delete-cancel cursor-pointer" data-dismiss="modal">Cancel
                    </button>
                    <button type="button" class="btn delete-yes cursor-pointer">Yes</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/menuCategory/menu-category-list.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/menuCategory/menu_category_list.blade.php ENDPATH**/ ?>