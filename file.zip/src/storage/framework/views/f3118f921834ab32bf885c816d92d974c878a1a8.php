<?php $__env->startSection('title'); ?>
    <h2>Order detail</h2>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="row">
        <div class="col-md-9 border">
            <table class="table table-bordered">
                <tr>
                    <th><b>DRINK</b></th>
                    <th><b>PRICE</b></th>
                    <th><b>QUANTITY</b></th>
                    <th><b>TOTAL</b></th>
                </tr>
                <?php $__currentLoopData = $result['orderDetailList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td colspan="4"><b><?php echo e($key); ?></b></td>
                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order['menuName']); ?></td>
                            <td><?php echo e($order['price']); ?></td>
                            <td><?php echo e($order['quantity']); ?></td>
                            <td><?php echo e($order['price']*$order['quantity']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>
        <div class="order-info col-md-3">
            <table class="table table-bordered">
                <tr>
                    <td>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-key"></i> Order Id:</p>
                            <p class="col-md-6"><?php echo e($result['orderData']['orderId']); ?></p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-user"></i> User Name:</p>
                            <p class="col-md-6"><?php echo e($result['orderData']['username']); ?></p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-calendar"></i> Datetime:</p>
                            <p class="col-md-6"><?php echo e($result['orderData']['datetime']); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <h3>
                            <strong>MONEY TOTAL</strong>
                            <p><?php echo e($result['totalPrice']); ?> VND</p>
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <a href="<?php echo e(route('order.showOrderEditForm',$result['orderData']['orderId'])); ?>">
                            <button type="button" class="btn">
                                <i class="fa fa-edit"> </i> Edit
                            </button>
                        </a>
                    </td>
                </tr>
            </table>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/order-detail/order-detail.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/order/order_detail.blade.php ENDPATH**/ ?>