<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login</title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo e(asset('vendors/animate.css/animate.min.css')); ?>" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('vendors/build/css/custom.min.css')); ?>" rel="stylesheet">
</head>

<body class="login">
<div>
    <div class="login_wrapper">
        <div class="animate form login_form">
            <section class="login_content">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <h1>Login</h1>
                    <div style="margin-bottom: 5px">
                        <input type="text" class="form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('username')); ?>"
                               placeholder="Username" required name="username" style="margin-bottom: 0"/>
                        <span class="invalid-feedback red <?php echo e($errors->has('username') ? 'visible' : 'invisible'); ?>"
                              role="alert">
                            <strong><?php echo e($errors->first('username')); ?> &nbsp;</strong>
                        </span>
                    </div>
                    <div>
                        <input type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('password')); ?>"
                               placeholder="Password" required name="password"/>
                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <button class="btn btn-default submit">Log in</button>
                    </div>
                </form>
            </section>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/auth/login.blade.php ENDPATH**/ ?>