<div class="profile clearfix">
    <div class="profile_pic">
        <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" alt="..." class="img-circle profile_img">
    </div>
    <div class="profile_info" style="color: white">
        <h1><?php echo e(Auth::user()->username); ?></h1>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/layout/menu/menu_profile.blade.php ENDPATH**/ ?>