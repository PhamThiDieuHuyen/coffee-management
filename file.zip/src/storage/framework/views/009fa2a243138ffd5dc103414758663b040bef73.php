<?php $__env->startSection('title'); ?>
    <h2>Order edit</h2>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('order.updateOrder')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        
        <div class="col-md-9 border table-form">
            
            <input type="text" name="orderId" value="<?php echo e($result['orderData']['orderId']); ?>" hidden>

            
            <div class="border">
                <table class="table table-bordered" id="order-table">
                    <tr>
                        <th><b>Category</b></th>
                        <th><b>DRINK</b></th>
                        <th style="width: 50px"><b>PRICE</b></th>
                        <th><b>QUANTITY</b></th>
                        <th><b>TOTAL</b></th>
                        <th><b>DELETE</b></th>
                    </tr>
                    <?php $rowIndex = 0 ?>
                    <?php $__currentLoopData = $result['orderDetailData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetailRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $rowIndex++ ?>
                        <tr>
                            <td>
                                <select name="menuCategoryId[]" class="menu-category-id" data-row-index="<?php echo e($rowIndex); ?>">
                                    <?php $__currentLoopData = $result['menuCategoryList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($orderDetailRow['menuCategoryId']==$menuCategory['menuCategoryId']): ?>
                                            <option value="<?php echo e($menuCategory['menuCategoryId']); ?>" selected>
                                                <?php echo e($menuCategory['name']); ?>

                                            </option>
                                        <?php else: ?>
                                            <option class="menu-category-id-<?php echo e($menuCategory['menuCategoryId']); ?>"
                                                    value="<?php echo e($menuCategory['menuCategoryId']); ?>">
                                                <?php echo e($menuCategory['name']); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <select name="menuId[]" class="menu-id">
                                    <?php $__currentLoopData = $result['menuList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option hidden value="">------</option>
                                        <?php if($orderDetailRow['menuId']==$menu['menuId']): ?>
                                            <option class="menu-category-id-<?php echo e($menu['menuCategoryId']); ?>"
                                                    data-menu-price="<?php echo e($menu['price']); ?>"
                                                    value="<?php echo e($menu['menuId']); ?>"
                                                    selected>
                                                <?php echo e($menu['name']); ?>

                                            </option>
                                        <?php elseif($menu['menuCategoryId']==$orderDetailRow['menuCategoryId']): ?>
                                            <option class="menu-category-id-<?php echo e($menu['menuCategoryId']); ?>"
                                                    data-menu-price="<?php echo e($menu['price']); ?>"
                                                    value="<?php echo e($menu['menuId']); ?>">
                                                <?php echo e($menu['name']); ?>

                                            </option>
                                        <?php else: ?>
                                            <option class="menu-category-id-<?php echo e($menu['menuCategoryId']); ?>"
                                                    data-menu-price="<?php echo e($menu['price']); ?>"
                                                    value="<?php echo e($menu['menuId']); ?>" hidden>
                                                <?php echo e($menu['name']); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="menuPrice" class="menu-price" disabled
                                       value="<?php echo e($orderDetailRow['price']); ?>">
                            </td>
                            <td>
                                <input type="number" name="menuQuantity[]"
                                       min="0"
                                       class="menu-quantity"
                                       value="<?php echo e($orderDetailRow['quantity']); ?>">
                            </td>
                            <td>
                                <input type="number" name="menuTotal"  class="menu-total" disabled
                                       value="<?php echo e($orderDetailRow['price']*$orderDetailRow['quantity']); ?>">
                            </td>
                            <td>
                                <button type="button" class="delete-order btn cursor-pointer "
                                        data-order-id="<?php echo e($orderDetailRow['orderId']); ?>">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <tr>
                        <td class="text-center" colspan="6">
                            <button type="button" class="btn append-order">
                                <i class="fa fa-plus-square"></i>
                            </button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="order-info col-md-3">
            <table class="table table-bordered">
                <tr>
                    <td>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-key"></i> Order Id:</p>
                            <p class="col-md-6"><?php echo e($result['orderData']['orderId']); ?></p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-user"></i> User Name:</p>
                            <p class="col-md-6"><?php echo e($result['orderData']['username']); ?></p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-calendar"></i> Datetime:</p>
                            <p class="col-md-6"><?php echo e($result['orderData']['datetime']); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <h3>
                            <strong>MONEY TOTAL</strong><br>
                            <span class="order-money-total"><?php echo e($result['totalPrice']); ?></span>
                            <span>VND</span>
                        </h3>

                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <button type="submit" class="btn update-order"
                                data-order-id="<?php echo e($result['orderData']['orderId']); ?>">
                            <i class="fa fa-refresh"> </i> Update
                        </button>
                    </td>
                </tr>
            </table>
        </div>
    </form>
    <table hidden>

        
        <tbody hidden class="append-row">
        <tr>
            <td>
                <select name="menuCategoryId[]" class="menu-category-id">

                    <option selected disabled hidden>------</option>
                    <?php $__currentLoopData = $result['menuCategoryList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($menuCategory['menuCategoryId']); ?>">
                            <?php echo e($menuCategory['name']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <select name="menuId[]" class="menu-id">
                    <option selected hidden value="">------</option>
                    <?php $__currentLoopData = $result['menuList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="menu-category-id-<?php echo e($menu['menuCategoryId']); ?>"
                                data-menu-price="<?php echo e($menu['price']); ?>"
                                value="<?php echo e($menu['menuId']); ?>" hidden>
                            <?php echo e($menu['name']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <input type="number" name="menuPrice" class="menu-price"
                       value="0" disabled>
            </td>
            <td>
                <input type="number" name="menuQuantity[]"
                       min="0"
                       class="menu-quantity"
                       value="0">
            </td>
            <td>
                <input type="number" name="menuTotal" class="menu-total"
                       value="0" disabled>
            </td>
            <td>
                <button type="button" class="delete-order btn cursor-pointer "
                        data-order-id="<?php echo e($orderDetailRow['orderId']); ?>">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        </tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/order/order-edit.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/order/order-edit.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/order/order_edit.blade.php ENDPATH**/ ?>