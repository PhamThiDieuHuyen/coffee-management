<?php $__env->startSection('title'); ?>
    <h2>Order create</h2>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <ul class="nav nav-tabs tabs-left col-md-2 category-list" role="tablist">
        <?php $__currentLoopData = $result["menuCategoryList"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($menuCategory["menuCategoryId"]=="1"): ?>
                <li role="presentation" class="active">
                    <a href="#menu-category-tab-<?php echo e($menuCategory["menuCategoryId"]); ?>"
                       role="tab"
                       data-toggle="tab"><?php echo e($menuCategory["name"]); ?></a>
                </li>

            <?php else: ?>
                <li role="presentation">
                    <a href="#menu-category-tab-<?php echo e($menuCategory["menuCategoryId"]); ?>"
                       role="tab"
                       data-toggle="tab"><?php echo e($menuCategory["name"]); ?></a>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    
    <div id="grid-menu" class="row view-group col-md-5">
        <div class="tab-content">
            <?php $__currentLoopData = $result["menuCategoryList"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane <?php echo e($menuCategory["menuCategoryId"] == 1 ? 'active' : ''); ?>"
                     id="menu-category-tab-<?php echo e($menuCategory["menuCategoryId"]); ?>" role="tabpanel">
                    <?php $__currentLoopData = $result["menuList"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($menu["menuCategoryId"]==$menuCategory["menuCategoryId"]): ?>
                            
                            <div class="item col-md-4">
                                <div class="thumbnail card menu-layout menu-layout-<?php echo e($menu["menuId"]); ?> cursor-pointer"
                                     data-value="<?php echo e($menu["menuId"]); ?>">
                                    <div class="menu-image-layout">
                                        <img class="image-layout"
                                             src="<?php echo e(asset($menu["image"])); ?>"
                                             alt="">
                                    </div>
                                    <div class="menu-info-layout info-<?php echo e($menu["menuId"]); ?> text-center"
                                         data-menu-name="<?php echo e($menu["name"]); ?>"><?php echo e($menu["name"]); ?></div>
                                    <div class="menu-price-layout price-<?php echo e($menu["menuId"]); ?> row"
                                         data-menu-price="<?php echo e($menu["price"]); ?>">
                                        <div class="col-md-2 text-center menu-plus menu-plus-<?php echo e($menu["menuId"]); ?>">
                                            <i class="fa fa-plus"></i>
                                        </div>
                                        <div class="col-md-2 text-center menu-trash menu-trash-<?php echo e($menu["menuId"]); ?>"
                                             hidden>
                                            <i class="fa fa-trash"></i>
                                        </div>
                                        <div class="text-center"> <?php echo e($menu["price"]); ?>VND</div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    <form action="<?php echo e(route('order.createOrder')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="order-info col-md-5">
            <ul class="list-group">
                
                <li class="text-center money-total">
                    <div class="col-md-5">
                        <h2>
                            <strong>MONEY TOTAL</strong><br>
                        </h2>
                        <h3>0VND</h3>
                    </div>
                    <div class="col-md-7 payment">
                        <button type="submit" class="btn">
                            PAYMENT
                        </button>
                        <button type="button" class="btn order-reset">
                            RESET
                        </button>
                        </a>

                    </div>
                </li>
                
            </ul>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    
    <script type="text/javascript" src="<?php echo e(asset('js/order/order-create.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>

    
    <link href="<?php echo e(asset('css/order/order-create.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/order/order_create.blade.php ENDPATH**/ ?>