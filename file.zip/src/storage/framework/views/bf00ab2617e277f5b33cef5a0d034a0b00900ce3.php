<div class="pull-right">
    <a href="http://127.0.0.1:8000/">
        <i class="fa fa-gears"></i> Coffee Management</a>
</div>
<div class="clearfix"></div><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/layout/footer/footer.blade.php ENDPATH**/ ?>