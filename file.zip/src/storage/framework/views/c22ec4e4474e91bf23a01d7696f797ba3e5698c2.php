<?php $__env->startSection('title'); ?>
    <h2>Menu Category detail</h2>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('menuCategory.updateMenuCategory')); ?>"
          method="POST"
          class="form-horizontal form-label-left">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-10 col-sm-12 profile_details col-md-push-1 ">
            <div class="well profile_view w-100">
                <div class="menu-category-detail-profile col-sm-9">
                    
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name">
                            MENU CATEGORY ID
                        </label>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <input type="text" name="menuCategoryId"
                                   class="menu-category-id form-control col-md-7 col-xs-12"
                                   readonly
                                   value="<?php echo e($result['menuCategoryDetail']['menuCategoryId']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name">
                            MENU CATEGORY NAME
                        </label>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <input type="text" name="menuCategoryName"
                                   class="menu-category-name form-control col-md-7 col-xs-12" readonly
                                   value="<?php echo e($result['menuCategoryDetail']['name']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name">
                            DESCRIBE
                        </label>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                <textarea readonly name="menuCategoryDescribe"
                          class="menu-category-describe form-control col-md-7 col-xs-12"
                          rows="5"><?php echo e($result['menuCategoryDetail']['describe']); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12 bottom ">
                    <div class="col-md-offset-3 col-edit">
                        <button class="menu-category-cancel btn"
                                type="button" style='display:none'>
                            <i class="fa fa-close"> </i> Cancel
                        </button>
                        <button class="menu-category-edit btn"
                                type="button">
                            <i class="fa fa-edit"> </i> Edit
                        </button>
                        <button type="submit" class="menu-category-submit btn "
                                style='display:none'>
                            <i class="fa fa-check-circle"> </i> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript" src="<?php echo e(asset('js/menuCategory/menu-category-detail.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/menuCategory/menu-category-detail.css)); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> ?><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/menuCategory/menu_category_detail.blade.php ENDPATH**/ ?>