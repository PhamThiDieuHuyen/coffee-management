<?php $__env->startSection('title'); ?>
    <h2>Menu detail</h2>
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('menu.updateMenu')); ?>"
          method="POST"
          class="form-horizontal form-label-left"
          enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-10 col-sm-12 profile_details col-md-push-1 ">
            <div class="well profile_view w-100">
                <div class=" menu-detail-profile col-sm-12">
                    
                    <div class="information-profile left col-md-9 ">
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                MENU ID
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="menuId" class="menu-id form-control col-md-7 col-xs-12"
                                       readonly
                                       value="<?php echo e($result['menuDetail']['menuId']); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                MENU CATEGORY NAME
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select name="menuCategoryId" class="form-control col-md-7 col-xs-12 menu-category-name"
                                        disabled>
                                    <?php $__currentLoopData = $result['menuCategoryList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($menuCategory['menuCategoryId'] == $result['menuDetail']['menuCategoryId']): ?>
                                            <option selected
                                                    value="<?php echo e($menuCategory['menuCategoryId']); ?>"><?php echo e($menuCategory['name']); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($menuCategory['menuCategoryId']); ?>"><?php echo e($menuCategory['name']); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                MENU NAME
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="name" class="menu-name form-control col-md-7 col-xs-12"
                                       readonly
                                       value="<?php echo e($result['menuDetail']['name']); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                PRICE
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="price" class="menu-price form-control col-md-7 col-xs-12"
                                       readonly
                                       value="<?php echo e($result['menuDetail']['price']); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="right col-md-3 text-center">
                        <div class="frame-avatar">
                            <?php if($result['menuDetail']['image']): ?>
                                <img src="<?php echo e(asset($result['menuDetail']['image'])); ?>" alt=""
                                     class="img-center menu-image">
                            <?php else: ?>
                                <img src="<?php echo e(asset("images/no-image.png")); ?>" alt=""
                                     class="img-center">
                            <?php endif; ?>
                            <img src="<?php echo e(asset("images/no-image.png")); ?>" alt=""
                                 class="img-center avatar-none" hidden>
                        </div>
                        <label for="file-upload" class="custom-file-upload">
                            Choose
                        </label>
                        <span class="file-upload-info col-md-12"></span>
                        <input id="file-upload"
                               class="choose-file"
                               type="file"
                               name="fileUpload">
                    </div>
                </div>
                
                <div class="col-md-12 bottom ">
                    <div class="col-md-offset-3 col-edit">
                        <button type="button" class="menu-edit btn cursor-pointer">
                            <i class="fa fa-edit"> </i> Edit
                        </button>
                        <button type="button" class="menu-cancel btn cursor-pointer"
                                style='display:none'>
                            <i class="fa fa-close"> </i> Cancel
                        </button>
                        <button type="submit" name="up"
                                class="menu-submit btn cursor-pointer"
                                style='display:none'>
                            <i class="fa fa-check-circle"> </i> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript" src="<?php echo e(asset('js/menu/menu-detail.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/menu/menu-detail.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffee-management\src\resources\views/menu/menu_detail.blade.php ENDPATH**/ ?>