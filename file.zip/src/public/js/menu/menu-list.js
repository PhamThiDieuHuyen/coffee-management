const MenuList = {
    init: function () {
        this.initMenuTable();
        this.menuRowClick();
        this.showDeleteModal();
        this.deleteMenu();
    },
    /**
     * Set init data table
     */
    initMenuTable: function () {
        $('#menu-table').DataTable();
    },
    /**
     * Menu row click
     */
    menuRowClick: function () {
        $('#menu-table').on("click", ".menu-row",function () {
            const menuId = $(this).data('menu-id');
            const detailMenuUrl = "detail/" + menuId;
            window.location.replace(detailMenuUrl);
        });
    },
    showDeleteModal: function () {
        $('#menu-table').on('click', '.delete-menu', function (event) {
            event.stopPropagation();
            const menuId = $(this).data('menu-id');
            $('.delete-yes').data('menu-id',menuId);
            $('.confirm-delete-modal').modal('show');
        })
    },
    deleteMenu: function () {
        $('.delete-yes').click(function () {
            const menuId = $(this).data('menu-id');
            window.location.replace('delete/'+menuId);
        })
    },
};

MenuList.init();