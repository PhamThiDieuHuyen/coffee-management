const MenuDetail = {
        init: function () {
            this.menuEditClick();
            this.menuCancelClick();
            this.uploadFileClick();
        },
        menuEditClick: function () {
            $('.menu-edit').click(function () {
                $('.menu-category-name').attr("disabled", false);
                $('.menu-name').attr("readonly", false);
                $('.menu-price').attr("readonly", false);
                $('.menu-edit').hide();
                $('.menu-cancel').show();
                $('.menu-submit').show();
                $('.custom-file-upload').show();
            });
        },
        menuCancelClick: function () {
            $('.menu-cancel').click(function () {
                $('.menu-category-name').attr("disabled", true);
                $('.menu-name').attr("readonly", true);
                $('.menu-price').attr("readonly", true);
                $('.menu-edit').show();
                $('.menu-cancel').hide();
                $('.menu-submit').hide();
                $('.custom-file-upload').hide();
            });
        },
        uploadFileClick: function () {
            $('.choose-file').change(function () {
                $(".menu-image").hide();
                $(".avatar-none").show();
                const filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
                $('.file-upload-info').text(filename);
            })
        }
    }
;
MenuDetail.init();