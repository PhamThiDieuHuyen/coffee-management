const MenuCategoryDetail = {
        init: function () {
            this.menuCategoryDeleteClick();
            this.menuCategoryEditClick();
            this.menuCategoryCancelClick();
        },
        menuCategoryDeleteClick: function () {
            $('.delete-yes').click(function (){
                const menuCategoryId = $('.menu-category-id').val();
                window.location.replace('/menuCategory/delete/' + menuCategoryId);
            });
        },
        menuCategoryEditClick: function () {
            $('.menu-category-edit').click(function () {
                $('.menu-category-name').attr("readonly", false);
                $('.menu-category-describe').attr("readonly", false);
                $('.menu-category-delete').hide();
                $('.menu-category-edit').hide();
                $('.menu-category-cancel').show();
                $('.menu-category-submit').show();
            });
        },
        menuCategoryCancelClick: function () {
        $('.menu-category-cancel').click(function () {
            $('.menu-category-name').attr("readonly", true);
            $('.menu-category-describe').attr("readonly", true);
            $('.menu-category-delete').show();
            $('.menu-category-edit').show();
            $('.menu-category-cancel').hide();
            $('.menu-category-submit').hide();
        });
    },
    }
;
MenuCategoryDetail.init();