const MenuCategoryList = {
    init: function () {
        this.initMenuCategoryTable();
        this.menuCategoryRowClick();
        this.showDeleteModal();
        this.deleteMenuCategory();
    },
    /**
     * Set init data table
     */
    initMenuCategoryTable: function () {
        $('#menu-category-table').DataTable();
    },
    /**
     * MenuCategory row click
     */
    menuCategoryRowClick: function () {
        $('#menu-category-table').on('click', '.menu-category-row', function () {
            const menuCategoryId = $(this).data('menu-category-id');
            const detailMenuCategoryUrl = "detail/" + menuCategoryId;
            window.location.replace(detailMenuCategoryUrl);
        });
    },
    showDeleteModal: function () {
        $('#menu-category-table').on('click', '.delete-menu-category', function (event) {
            event.stopPropagation();
            const menuCategoryId = $(this).data('menu-category-id');
            $('.delete-yes').data('menu-category-id',menuCategoryId);
            $('.confirm-delete-modal').modal('show');
        })
    },
    deleteMenuCategory: function () {
        $('.delete-yes').click(function () {
            const menuCategoryId = $(this).data('menu-category-id');
            window.location.replace('delete/'+menuCategoryId);
        })
    },
};
MenuCategoryList.init();