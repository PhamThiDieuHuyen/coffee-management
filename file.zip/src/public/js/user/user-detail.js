const UserDetail = {

    init: function () {
        this.userEditClick();
        this.userCancelClick();
        this.uploadFileClick();
    },
    userEditClick: function () {
        $('.user-edit').click(function () {
            $('.user-name-input').attr("readonly", false);
            $('.user-permission-input').attr("readonly", false);
            $('.user-address-input').attr("readonly", false);
            $('.user-phone-input').attr("readonly", false);
            $('.user-submit').show();
            $('.user-cancel').show();
            $('.custom-file-upload').show();
            $('.user-edit').hide();
        });
    },
    userCancelClick: function () {
        $('.user-cancel').click(function () {
            $('.user-name-input').attr("readonly", true);
            $('.user-permission-input').attr("readonly", true);
            $('.user-address-input').attr("readonly", true);
            $('.user-phone-input').attr("readonly", true);
            $('.user-submit').hide();
            $('.user-cancel').hide();
            $('.custom-file-upload').hide();
            $('.user-edit').show();
        });
    },
    uploadFileClick: function () {
        $('.choose-file').change(function () {
            $(".user-avatar").hide();
            $(".avatar-none").show();
            const filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
            $('.file-upload-info').text(filename);
        })
    }
};
UserDetail.init();