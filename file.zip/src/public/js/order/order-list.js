const OrderList = {
    init: function () {
        this.initOrderTable();
        this.orderRowClick();
        this.showDeleteModal();
        this.deleteOrder();
    },

    initOrderTable: function () {
        $('#order-table').DataTable();
    },
    orderRowClick: function () {
        $('#order-table').on('click', '.order-row', function () {
            const orderId = $(this).data('order-id');
            const detailOrderUrl = 'detail/' + orderId;
            window.location.replace(detailOrderUrl);
        });
    },
    showDeleteModal: function () {
        $('#order-table').on('click', '.delete-order', function (event) {
            event.stopPropagation();
            const orderId = $(this).data('order-id');
            $('.delete-yes').data('order-id',orderId);
            $('.confirm-delete-modal').modal('show');
        })
    },
    deleteOrder: function () {
        $('.delete-yes').click(function () {
            const orderId = $(this).data('order-id');
            window.location.replace('delete/'+orderId);
        })
    },
};
OrderList.init();