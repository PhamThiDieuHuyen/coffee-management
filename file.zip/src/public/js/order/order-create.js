const OrderCreate = {
    init: function () {
        this.clickAddMenu();
        this.clickMenuRemove();
        this.clickMenuQuantitySub();
        this.clickMenuQuantityAdd();
        this.resetOrderCreate();
    },
    clickAddMenu: function () {
        const $this = this;
        $('#grid-menu').on('click', '.menu-layout', function () {

            // get menu number, menu name, menu price value and $menuRowId
            const menuId = $(this).data('value');
            const menuName = $('.info-' + menuId).data('menu-name');
            const menuTotalPrice = $('.price-' + menuId).data('menu-price');
            const $menuRowId = $(".menu-row-" + menuId);

            // check menu row id exist

            if (!$($menuRowId).length) {

                // get menu row html
                let menuRowHtml = "";
                menuRowHtml += "<li class='list-group-item menu-row menu-row-" + menuId + "' data-value='" + menuId + "'>";
                menuRowHtml += "    <input hidden name='menuId[]' value='" + menuId + "'>";
                menuRowHtml += "    <input hidden name='quantity[]' class='quantity-" + menuId + "' value='" + 1 + "'>";
                menuRowHtml += "    <span class='col-md-1 menu-number text-center'>";
                menuRowHtml += "    </span>";
                menuRowHtml += "    <span class='col-md-6 menu-name'>";
                menuRowHtml += menuName;
                menuRowHtml += "    </span>";
                menuRowHtml += "    <span class='col-md-1 menu-quantity-sub' data-value='" + menuId + "'>";
                menuRowHtml += "        <i class='fa fa-minus'>";
                menuRowHtml += "        </i>";
                menuRowHtml += "    </span>";
                menuRowHtml += "    <span class='col-md-1 menu-quantity menu-quantity-" + menuId + "'>1";
                menuRowHtml += "    </span>";
                menuRowHtml += "    <span class='col-md-1 menu-quantity-add' data-value='" + menuId + "'>";
                menuRowHtml += "        <i class='fa fa-plus'>";
                menuRowHtml += "        </i>";
                menuRowHtml += "    </span>";
                menuRowHtml += "    <span class='col-md-2 menu-total-price menu-total-price-" + menuId + " text-center'>";
                menuRowHtml += menuTotalPrice;
                menuRowHtml += "    </span>";
                menuRowHtml += "    <span class='col-md-1 menu-remove' data-value='" + menuId + "'>";
                menuRowHtml += "        <i class='fa fa-trash'>";
                menuRowHtml += "        </i>";
                menuRowHtml += "    </span>";
                menuRowHtml += "</li>";

                // add class selected menu
                $(this).addClass("selected-menu");

                // toggle plus and trash at menu layout
                $(".menu-plus-" + menuId).toggle();
                $(".menu-trash-" + menuId).toggle();

                // get order info ul(list group)
                const $listGroupOrderInfo = $(".order-info").children();

                // append menu row html to order info ul
                $listGroupOrderInfo.append(menuRowHtml);
            } else {
                // remove menu row
                $menuRowId.remove();

                // remove class selected menu
                $(this).removeClass("selected-menu");

                // toggle plus and trash at menu layout
                $(".menu-plus-" + menuId).toggle();
                $(".menu-trash-" + menuId).toggle();
            }
            // reset number order info
            $this.numberOrderItem();

            // update order total price
            $this.calculateTotalOrder();
        })
    },
    clickMenuQuantityAdd: function () {
        const $this = this;
        $('.order-info').on('click', '.menu-quantity-add', function () {
            // get menu id value
            const menuId = $(this).data("value");

            // get menu quantity
            const $menuQuantity = $(".menu-quantity-" + menuId);
            let menuQuantityInt = parseInt($menuQuantity.text());
            if (menuQuantityInt === 99) {
                new PNotify({
                    title: 'Validation',
                    text: 'Quantity cannot more than 99!',
                    type: 'warning',
                    styling: 'bootstrap3',
                    stack: {
                        dir1: 'left', dir2: 'down', // Position from the top left corner.
                        firstpos1: 10, firstpos2: 500 // 90px from the top, 90px from the left.
                    }
                });
            } else {
                // set text menu quantity
                $menuQuantity.text(menuQuantityInt + 1);
                // set value quantity input hidden
                $('.quantity-' + menuId).attr('value',parseInt($menuQuantity.text()));
            }

            // update menu total price
            const $menuPriceLayout = $(".price-" + menuId);
            const menuPriceLayoutInt = parseInt($menuPriceLayout.text());
            const $menuTotalPrice = $(".menu-total-price-" + menuId);
            $menuTotalPrice.text(parseInt($menuQuantity.text()) * menuPriceLayoutInt);

            // update order total price
            $this.calculateTotalOrder();
        })
    },
    clickMenuQuantitySub: function () {
        const $this = this;
        $('.order-info').on('click', '.menu-quantity-sub', function () {
            // get menu id value
            const menuId = $(this).data("value");

            // get menu quantity
            const $menuQuantity = $(".menu-quantity-" + menuId);
            let menuQuantityInt = parseInt($menuQuantity.text());

            if (menuQuantityInt === 1) {
                new PNotify({
                    title: 'Validation',
                    text: 'Quantity cannot less than 0!',
                    type: 'warning',
                    styling: 'bootstrap3',
                    stack: {
                        dir1: 'left', dir2: 'down', // Position from the top left corner.
                        firstpos1: 10, firstpos2: 500 // 90px from the top, 90px from the left.
                    }
                });
            } else {
                // set text menu quantity
                $menuQuantity.text(menuQuantityInt - 1);
                // set value quantity input hidden
                $('.quantity-' + menuId).attr('value',parseInt($menuQuantity.text()));
            }
            // update menu total price
            const $menuPriceLayout = $(".price-" + menuId);
            const menuPriceLayoutInt = parseInt($menuPriceLayout.text());
            const $menuTotalPrice = $(".menu-total-price-" + menuId);
            $menuTotalPrice.text(parseInt($menuQuantity.text()) * menuPriceLayoutInt);

            // update order total price
            $this.calculateTotalOrder();
        })
    },
    clickMenuRemove: function () {
        const $this = this;
        $('.order-info').on('click', '.menu-remove', function () {
            // get menu id value
            const menuId = $(this).data("value");

            // remove menu row
            const $menuRowId = $(".menu-row-" + menuId);
            $menuRowId.remove();

            // remove class selected menu
            $(".menu-layout-" + menuId).removeClass("selected-menu");

            // toggle plus and trash at menu layout
            $(".menu-plus-" + menuId).toggle();
            $(".menu-trash-" + menuId).toggle();

            // reset number order info
            $this.numberOrderItem();

            // update order total price
            $this.calculateTotalOrder();
        })
    },
    resetOrderCreate: function (){
        const $this = this;
        $('.order-info').on('click', '.order-reset', function () {
            const $orderItemList = $(".list-group-item");
            $orderItemList.each(function () {
                // remove menu row
                $(this).remove();

                // get menuId
                let menuId = $(this).data('value');
                // remove class selected menu
                $(".menu-layout-" + menuId).removeClass("selected-menu");

                // toggle plus and trash at menu layout
                $(".menu-plus-" + menuId).toggle();
                $(".menu-trash-" + menuId).toggle();
            });
            // update order total price
            $this.calculateTotalOrder();
        })
    },
    calculateTotalOrder: function () {
        const $orderItemList = $(".list-group-item");
        let moneyTotal = 0;
        $orderItemList.each(function () {
            const $menuTotalPrice = $(this).find('.menu-total-price');
            moneyTotal += parseInt($menuTotalPrice.text());
        });
        $(".money-total").find("h3").text(moneyTotal + "VND")
    },
    numberOrderItem: function () {
        const $orderItemList = $(".list-group-item");
        let index = 1;
        $orderItemList.each(function () {
            const $menuNumber = $(this).find('.menu-number');
            $menuNumber.text(index + ".");
            index++;
        });
    },
};
OrderCreate.init();