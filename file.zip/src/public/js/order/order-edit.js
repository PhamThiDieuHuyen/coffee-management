const OrderList = {
    init: function () {
        this.deleteOrderDetail();
        this.appendOrderDetail();
        this.selectMenuCategoryId();
        this.selectMenuId();
        this.changeQuantity();
        this.calculateTotalOrder();
    },
    deleteOrderDetail: function () {
        const $this = this;
        $('#order-table').on('click', '.delete-order', function () {
            $(this).parents('tr').remove();
            // calculate order total
            $this.calculateTotalOrder();
        })
    },
    appendOrderDetail: function () {
        $('.append-order').click(function (event) {
            event.stopPropagation();
            let rowOrderAppendHtml = $('.append-row').html();
            $(this).parents('tr').before(rowOrderAppendHtml);
        })
    },
    selectMenuCategoryId: function () {
        const $this = this;
        $('#order-table').on('change', '.menu-category-id', function () {
            const menuCategoryId = $(this).val();

            // get $menuSelectBox
            const $orderRow = $(this).parents('tr');
            const $menuSelectBox = $orderRow.find('.menu-id');


            // hide all option
            const $allMenuOption = $menuSelectBox.children();
            $allMenuOption.hide();

            // show target option
            const $targetMenuOption = $menuSelectBox.children('.menu-category-id-' + menuCategoryId);
            $targetMenuOption.show();

            // get null value
            $menuSelectBox.val("");

            // reset value price, quantity, total
            const $priceInputBox = $orderRow.find('.menu-price');
            $priceInputBox.val(0);
            const $quantityInputBox = $orderRow.find('.menu-quantity');
            $quantityInputBox.val(0);
            const $totalInputBox = $orderRow.find('.menu-total');
            $totalInputBox.val(0);

            // calculate order total
            $this.calculateTotalOrder();
        })
    },
    selectMenuId: function () {
        const $this = this;
        $('#order-table').on('change', '.menu-id', function () {
            // get price value
            const $selectedOption = $(this).children(':selected');
            const price = $selectedOption.data('menu-price');

            // get row
            const $orderRow = $(this).parents('tr');

            // set value price, quantity, total, order total
            const $priceInputBox = $orderRow.find('.menu-price');
            $priceInputBox.val(price);
            const $quantityInputBox = $orderRow.find('.menu-quantity');
            if ($quantityInputBox.val() === '0') {
                $quantityInputBox.val(1);
            }
            const $totalInputBox = $orderRow.find('.menu-total');
            $totalInputBox.val(price * $quantityInputBox.val());

            // calculate order total
            $this.calculateTotalOrder();
        })
    },
    changeQuantity: function () {
        const $this = this;
        $('#order-table').on('change', '.menu-quantity', function () {
            // get row
            const $orderRow = $(this).parents('tr');

            // set value price, quantity, total, order total
            const $priceInputBox = $orderRow.find('.menu-price');
            const $totalInputBox = $orderRow.find('.menu-total');
            $totalInputBox.val($priceInputBox.val() * $(this).val());

            // calculate order total
            $this.calculateTotalOrder();
        })
    },
    calculateTotalOrder: function () {
        let totalOrder = 0;
        const $totalInputBoxList = $('#order-table').find('.menu-total');
        $totalInputBoxList.each(function () {
            if ($(this).val()) {
                totalOrder += parseInt($(this).val(), 10);
            }
        });
        $('.order-money-total').text(totalOrder);
    },
};


OrderList.init();