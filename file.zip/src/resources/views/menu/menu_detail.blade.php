@extends('layout.main')

@section('title')
    <h2>Menu detail</h2>
    <div class="clearfix"></div>
@endsection

@section('content')
    <form action="{{ route('menu.updateMenu') }}"
          method="POST"
          class="form-horizontal form-label-left"
          enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="col-md-10 col-sm-12 profile_details col-md-push-1 ">
            <div class="well profile_view w-100">
                <div class=" menu-detail-profile col-sm-12">
                    {{--                Information--}}
                    <div class="information-profile left col-md-9 ">
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                MENU ID
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="menuId" class="menu-id form-control col-md-7 col-xs-12"
                                       readonly
                                       value="{{$result['menuDetail']['menuId']}}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                MENU CATEGORY NAME
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select name="menuCategoryId" class="form-control col-md-7 col-xs-12 menu-category-name"
                                        disabled>
                                    @foreach($result['menuCategoryList'] as $menuCategory)
                                        @if($menuCategory['menuCategoryId'] == $result['menuDetail']['menuCategoryId'])
                                            <option selected
                                                    value="{{$menuCategory['menuCategoryId']}}">{{$menuCategory['name']}}</option>
                                        @else
                                            <option value="{{$menuCategory['menuCategoryId']}}">{{$menuCategory['name']}}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                MENU NAME
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="name" class="menu-name form-control col-md-7 col-xs-12"
                                       readonly
                                       value="{{$result['menuDetail']['name']}}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-4 col-sm-4 col-xs-12">
                                PRICE
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="price" class="menu-price form-control col-md-7 col-xs-12"
                                       readonly
                                       value="{{$result['menuDetail']['price']}}">
                            </div>
                        </div>
                    </div>
                    {{--                Image--}}
                    <div class="right col-md-3 text-center">
                        <div class="frame-avatar">
                            @if($result['menuDetail']['image'])
                                <img src="{{asset($result['menuDetail']['image'])}}" alt=""
                                     class="img-center menu-image">
                            @else
                                <img src="{{asset("images/no-image.png")}}" alt=""
                                     class="img-center">
                            @endif
                            <img src="{{asset("images/no-image.png")}}" alt=""
                                 class="img-center avatar-none" hidden>
                        </div>
                        <label for="file-upload" class="custom-file-upload">
                            Choose
                        </label>
                        <span class="file-upload-info col-md-12"></span>
                        <input id="file-upload"
                               class="choose-file"
                               type="file"
                               name="fileUpload">
                    </div>
                </div>
                {{--                Buttons--}}
                <div class="col-md-12 bottom ">
                    <div class="col-md-offset-3 col-edit">
                        <button type="button" class="menu-edit btn cursor-pointer">
                            <i class="fa fa-edit"> </i> Edit
                        </button>
                        <button type="button" class="menu-cancel btn cursor-pointer"
                                style='display:none'>
                            <i class="fa fa-close"> </i> Cancel
                        </button>
                        <button type="submit" name="up"
                                class="menu-submit btn cursor-pointer"
                                style='display:none'>
                            <i class="fa fa-check-circle"> </i> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>

@endsection

@push('scripts')

    <script type="text/javascript" src="{{ asset('js/menu/menu-detail.js') }}"></script>
@endpush
{{--@push('styles')--}}
{{--    <link href="{{ asset('css/menu/menu-detail.css') }}" rel="stylesheet">--}}
{{--@endpush--}}