@extends('layout.main')

@section('title')
    <h2>Menu Category detail</h2>
    <div class="clearfix"></div>
@endsection

@section('content')
    <form action="{{ route('menuCategory.updateMenuCategory') }}"
          method="POST"
          class="form-horizontal form-label-left">
        {{ csrf_field() }}
        <div class="col-md-10 col-sm-12 profile_details col-md-push-1 ">
            <div class="well profile_view w-100">
                <div class="menu-category-detail-profile col-sm-9">
                    {{--                Information--}}
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name">
                            MENU CATEGORY ID
                        </label>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <input type="text" name="menuCategoryId"
                                   class="menu-category-id form-control col-md-7 col-xs-12"
                                   readonly
                                   value="{{$result['menuCategoryDetail']['menuCategoryId']}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name">
                            MENU CATEGORY NAME
                        </label>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <input type="text" name="menuCategoryName"
                                   class="menu-category-name form-control col-md-7 col-xs-12" readonly
                                   value="{{$result['menuCategoryDetail']['name']}}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4 col-xs-12" for="first-name">
                            DESCRIBE
                        </label>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                <textarea readonly name="menuCategoryDescribe"
                          class="menu-category-describe form-control col-md-7 col-xs-12"
                          rows="5">{{$result['menuCategoryDetail']['describe']}}</textarea>
                        </div>
                    </div>
                </div>
                {{--                Buttons--}}
                <div class="col-md-12 bottom ">
                    <div class="col-md-offset-3 col-edit">
                        <button class="menu-category-cancel btn"
                                type="button" style='display:none'>
                            <i class="fa fa-close"> </i> Cancel
                        </button>
                        <button class="menu-category-edit btn"
                                type="button">
                            <i class="fa fa-edit"> </i> Edit
                        </button>
                        <button type="submit" class="menu-category-submit btn "
                                style='display:none'>
                            <i class="fa fa-check-circle"> </i> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection

@push('scripts')

    <script type="text/javascript" src="{{ asset('js/menuCategory/menu-category-detail.js') }}"></script>
@endpush

{{--@push('styles')--}}
{{--    <link href="{{ asset('css/menuCategory/menu-category-detail.css) }}" rel="stylesheet">--}}
{{--@endpush--}}