@extends('layout.main')

@section('title')
    <h2>Order detail</h2>
    <div class="clearfix"></div>
@endsection

@section('content')
    {{--        @php--}}
    {{--            dd($result['orderDetailList']);--}}
    {{--        @endphp--}}

    <div class="row">
        <div class="col-md-9 border">
            <table class="table table-bordered">
                <tr>
                    <th><b>DRINK</b></th>
                    <th><b>PRICE</b></th>
                    <th><b>QUANTITY</b></th>
                    <th><b>TOTAL</b></th>
                </tr>
                @foreach($result['orderDetailList'] as $key => $value)
                    <td colspan="4"><b>{{$key}}</b></td>
                    @foreach($value as $order)
                        <tr>
                            <td>{{$order['menuName']}}</td>
                            <td>{{$order['price']}}</td>
                            <td>{{$order['quantity']}}</td>
                            <td>{{$order['price']*$order['quantity']}}</td>
                        </tr>
                    @endforeach
                @endforeach

            </table>
        </div>
        <div class="order-info col-md-3">
            <table class="table table-bordered">
                <tr>
                    <td>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-key"></i> Order Id:</p>
                            <p class="col-md-6">{{$result['orderData']['orderId']}}</p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-user"></i> User Name:</p>
                            <p class="col-md-6">{{$result['orderData']['username']}}</p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-calendar"></i> Datetime:</p>
                            <p class="col-md-6">{{$result['orderData']['datetime']}}</p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <h3>
                            <strong>MONEY TOTAL</strong>
                            <p>{{$result['totalPrice']}} VND</p>
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <a href="{{ route('order.showOrderEditForm',$result['orderData']['orderId']) }}">
                            <button type="button" class="btn">
                                <i class="fa fa-edit"> </i> Edit
                            </button>
                        </a>
                    </td>
                </tr>
            </table>

        </div>
    </div>


@endsection

@push('scripts')

@endpush
@push('styles')
    <link href="{{ asset('css/order-detail/order-detail.css') }}" rel="stylesheet">
@endpush