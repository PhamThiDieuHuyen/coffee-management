@extends('layout.main')

@section('title')
    <h2>Order edit</h2>
    <div class="clearfix"></div>
@endsection

@section('content')
    <form action="{{ route('order.updateOrder') }}" method="post">
        {{ csrf_field() }}
        {{--        Order edit form--}}
        <div class="col-md-9 border table-form">
            {{--            data for submit--}}
            <input type="text" name="orderId" value="{{$result['orderData']['orderId']}}" hidden>

            {{--            table edit--}}
            <div class="border">
                <table class="table table-bordered" id="order-table">
                    <tr>
                        <th><b>Category</b></th>
                        <th><b>DRINK</b></th>
                        <th style="width: 50px"><b>PRICE</b></th>
                        <th><b>QUANTITY</b></th>
                        <th><b>TOTAL</b></th>
                        <th><b>DELETE</b></th>
                    </tr>
                    <?php $rowIndex = 0 ?>
                    @foreach($result['orderDetailData'] as $orderDetailRow)
                        <?php $rowIndex++ ?>
                        <tr>
                            <td>
                                <select name="menuCategoryId[]" class="menu-category-id" data-row-index="{{$rowIndex}}">
                                    @foreach($result['menuCategoryList'] as $menuCategory)
                                        @if($orderDetailRow['menuCategoryId']==$menuCategory['menuCategoryId'])
                                            <option value="{{$menuCategory['menuCategoryId']}}" selected>
                                                {{$menuCategory['name']}}
                                            </option>
                                        @else
                                            <option class="menu-category-id-{{$menuCategory['menuCategoryId']}}"
                                                    value="{{$menuCategory['menuCategoryId']}}">
                                                {{$menuCategory['name']}}
                                            </option>
                                        @endif
                                    @endforeach
                                </select>
                            </td>
                            <td>
                                <select name="menuId[]" class="menu-id">
                                    @foreach($result['menuList'] as $menu)
                                        <option hidden value="">------</option>
                                        @if($orderDetailRow['menuId']==$menu['menuId'])
                                            <option class="menu-category-id-{{$menu['menuCategoryId']}}"
                                                    data-menu-price="{{$menu['price']}}"
                                                    value="{{$menu['menuId']}}"
                                                    selected>
                                                {{$menu['name']}}
                                            </option>
                                        @elseif($menu['menuCategoryId']==$orderDetailRow['menuCategoryId'])
                                            <option class="menu-category-id-{{$menu['menuCategoryId']}}"
                                                    data-menu-price="{{$menu['price']}}"
                                                    value="{{$menu['menuId']}}">
                                                {{$menu['name']}}
                                            </option>
                                        @else
                                            <option class="menu-category-id-{{$menu['menuCategoryId']}}"
                                                    data-menu-price="{{$menu['price']}}"
                                                    value="{{$menu['menuId']}}" hidden>
                                                {{$menu['name']}}
                                            </option>
                                        @endif
                                    @endforeach
                                </select>
                            </td>
                            <td>
                                <input type="number" name="menuPrice" class="menu-price" disabled
                                       value="{{$orderDetailRow['price']}}">
                            </td>
                            <td>
                                <input type="number" name="menuQuantity[]"
                                       min="0"
                                       class="menu-quantity"
                                       value="{{$orderDetailRow['quantity']}}">
                            </td>
                            <td>
                                <input type="number" name="menuTotal"  class="menu-total" disabled
                                       value="{{$orderDetailRow['price']*$orderDetailRow['quantity']}}">
                            </td>
                            <td>
                                <button type="button" class="delete-order btn cursor-pointer "
                                        data-order-id="{{$orderDetailRow['orderId']}}">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    @endforeach

                    {{--                    Append button--}}
                    <tr>
                        <td class="text-center" colspan="6">
                            <button type="button" class="btn append-order">
                                <i class="fa fa-plus-square"></i>
                            </button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        {{--        Order information--}}
        <div class="order-info col-md-3">
            <table class="table table-bordered">
                <tr>
                    <td>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-key"></i> Order Id:</p>
                            <p class="col-md-6">{{$result['orderData']['orderId']}}</p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-user"></i> User Name:</p>
                            <p class="col-md-6">{{$result['orderData']['username']}}</p>
                        </div>
                        <div class="row">
                            <p class="col-md-6"><i class="fa fa-calendar"></i> Datetime:</p>
                            <p class="col-md-6">{{$result['orderData']['datetime']}}</p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <h3>
                            <strong>MONEY TOTAL</strong><br>
                            <span class="order-money-total">{{$result['totalPrice']}}</span>
                            <span>VND</span>
                        </h3>

                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <button type="submit" class="btn update-order"
                                data-order-id="{{$result['orderData']['orderId']}}">
                            <i class="fa fa-refresh"> </i> Update
                        </button>
                    </td>
                </tr>
            </table>
        </div>
    </form>
    <table hidden>

        {{--                    Append row--}}
        <tbody hidden class="append-row">
        <tr>
            <td>
                <select name="menuCategoryId[]" class="menu-category-id">

                    <option selected disabled hidden>------</option>
                    @foreach($result['menuCategoryList'] as $menuCategory)
                        <option value="{{$menuCategory['menuCategoryId']}}">
                            {{$menuCategory['name']}}
                        </option>
                    @endforeach
                </select>
            </td>
            <td>
                <select name="menuId[]" class="menu-id">
                    <option selected hidden value="">------</option>
                    @foreach($result['menuList'] as $menu)
                        <option class="menu-category-id-{{$menu['menuCategoryId']}}"
                                data-menu-price="{{$menu['price']}}"
                                value="{{$menu['menuId']}}" hidden>
                            {{$menu['name']}}
                        </option>
                    @endforeach
                </select>
            </td>
            <td>
                <input type="number" name="menuPrice" class="menu-price"
                       value="0" disabled>
            </td>
            <td>
                <input type="number" name="menuQuantity[]"
                       min="0"
                       class="menu-quantity"
                       value="0">
            </td>
            <td>
                <input type="number" name="menuTotal" class="menu-total"
                       value="0" disabled>
            </td>
            <td>
                <button type="button" class="delete-order btn cursor-pointer "
                        data-order-id="{{$orderDetailRow['orderId']}}">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        </tr>
        </tbody>
    </table>

@endsection

@push('scripts')
    <script type="text/javascript" src="{{ asset('js/order/order-edit.js') }}"></script>
@endpush
@push('styles')
    <link href="{{ asset('css/order/order-edit.css') }}" rel="stylesheet">
@endpush