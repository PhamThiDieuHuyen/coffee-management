@extends('layout.main')

@section('title')
    <h2>Order create</h2>
    <div class="clearfix"></div>
@endsection

@section('content')
    {{--        menu category--}}
    <ul class="nav nav-tabs tabs-left col-md-2 category-list" role="tablist">
        @foreach($result["menuCategoryList"] as $menuCategory)
            @if($menuCategory["menuCategoryId"]=="1")
                <li role="presentation" class="active">
                    <a href="#menu-category-tab-{{$menuCategory["menuCategoryId"]}}"
                       role="tab"
                       data-toggle="tab">{{$menuCategory["name"]}}</a>
                </li>

            @else
                <li role="presentation">
                    <a href="#menu-category-tab-{{$menuCategory["menuCategoryId"]}}"
                       role="tab"
                       data-toggle="tab">{{$menuCategory["name"]}}</a>
                </li>
            @endif
        @endforeach
    </ul>

    {{--grid menu list layoout--}}
    <div id="grid-menu" class="row view-group col-md-5">
        <div class="tab-content">
            @foreach($result["menuCategoryList"] as $menuCategory)
                <div class="tab-pane {{$menuCategory["menuCategoryId"] == 1 ? 'active' : ''}}"
                     id="menu-category-tab-{{$menuCategory["menuCategoryId"]}}" role="tabpanel">
                    @foreach($result["menuList"] as $menu)
                        @if($menu["menuCategoryId"]==$menuCategory["menuCategoryId"])
                            {{--                menu layout--}}
                            <div class="item col-md-4">
                                <div class="thumbnail card menu-layout menu-layout-{{$menu["menuId"]}} cursor-pointer"
                                     data-value="{{$menu["menuId"]}}">
                                    <div class="menu-image-layout">
                                        <img class="image-layout"
                                             src="{{ asset($menu["image"])}}"
                                             alt="">
                                    </div>
                                    <div class="menu-info-layout info-{{$menu["menuId"]}} text-center"
                                         data-menu-name="{{$menu["name"]}}">{{$menu["name"]}}</div>
                                    <div class="menu-price-layout price-{{$menu["menuId"]}} row"
                                         data-menu-price="{{$menu["price"]}}">
                                        <div class="col-md-2 text-center menu-plus menu-plus-{{$menu["menuId"]}}">
                                            <i class="fa fa-plus"></i>
                                        </div>
                                        <div class="col-md-2 text-center menu-trash menu-trash-{{$menu["menuId"]}}"
                                             hidden>
                                            <i class="fa fa-trash"></i>
                                        </div>
                                        <div class="text-center"> {{$menu["price"]}}VND</div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endforeach
                </div>
            @endforeach
        </div>
    </div>
    {{--order info--}}
    <form action="{{ route('order.createOrder') }}" method="post">
        {{ csrf_field() }}
        <div class="order-info col-md-5">
            <ul class="list-group">
                {{--            Money & payment--}}
                <li class="text-center money-total">
                    <div class="col-md-5">
                        <h2>
                            <strong>MONEY TOTAL</strong><br>
                        </h2>
                        <h3>0VND</h3>
                    </div>
                    <div class="col-md-7 payment">
                        <button type="submit" class="btn">
                            PAYMENT
                        </button>
                        <button type="button" class="btn order-reset">
                            RESET
                        </button>
                        </a>

                    </div>
                </li>
                {{--menu list append--}}
            </ul>
        </div>
    </form>
@endsection

@push('scripts')

    {{--    order-create--}}
    <script type="text/javascript" src="{{ asset('js/order/order-create.js') }}"></script>
@endpush
@push('styles')

    {{--    order-create--}}
    <link href="{{ asset('css/order/order-create.css') }}" rel="stylesheet">
@endpush